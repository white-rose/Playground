package com.company.uberjava;

public class UberStatistics {

    private int milesDriven;

    public int getMilesDriven() {
        return milesDriven;
    }

    public void setMilesDriven(int milesDriven) {
        this.milesDriven = milesDriven;
    }
}
