package com.company.uberjava;

public class UberRequest {

    String fromLocation;
    String toLocation;


}
