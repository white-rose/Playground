package com.company.uberjava.exceptions;

public class ValueNotSetException extends RuntimeException {
}
