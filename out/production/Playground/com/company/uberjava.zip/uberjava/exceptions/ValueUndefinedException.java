package com.company.uberjava.exceptions;

public class ValueUndefinedException extends Throwable {
}
