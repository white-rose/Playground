package com.company.uberjava;

public class Costs {

    Double costOfVehicleOwnership;
    Double operatingCosts;
    Double Tolls;
    Double costPerMileForGasoline;
    Double amenities;

}
