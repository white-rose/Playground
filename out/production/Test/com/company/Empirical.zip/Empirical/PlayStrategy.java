package com.company.Empirical;

public class PlayStrategy {
}
