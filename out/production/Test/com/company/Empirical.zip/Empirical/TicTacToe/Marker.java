package com.company.Empirical.TicTacToe;

/**
*
* This just deletes the marker
*/ 
public interface Marker {
    void delete();
}
