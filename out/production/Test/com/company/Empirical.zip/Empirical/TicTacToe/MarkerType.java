package com.company.Empirical.TicTacToe;

/**
*
* Just makes an enum for the marker types of X and O
*/

public enum MarkerType {X, O}

